package com.phycae.iot.model

data class User(
    var name: String? = null,
    var password: String? = null)