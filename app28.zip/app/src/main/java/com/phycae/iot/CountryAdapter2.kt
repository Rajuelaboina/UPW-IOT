package com.phycae.iot

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ArrayAdapter
import android.widget.Filter
import android.widget.TextView

class CountryAdapter2(context: Context, mLayoutResourceId: Int, var list: List<CountryNamesItem>, ) : ArrayAdapter<CountryNamesItem>(context,mLayoutResourceId){
    private val city: ArrayList<CountryNamesItem> = ArrayList(list)
    private var allCities: ArrayList<CountryNamesItem> = ArrayList(list)
    override fun getView(position: Int, convertView: View?, parent: ViewGroup): View {
       val view = LayoutInflater.from(parent!!.context).inflate(R.layout.row_item,null)
        val tv1 = view.findViewById<TextView>(R.id.textView_created_at)
        tv1.text = list[position].country_phone_code.toString()
        val tv2 = view.findViewById<TextView>(R.id.textView_feed)
        tv2.text = list[position].country_name
        return view
    }

    override fun getCount(): Int {
        return  list.size
    }

    override fun getItem(position: Int): CountryNamesItem {
        return list[position]
    }

    override fun getFilter(): Filter {
        return object : Filter() {
            override fun convertResultToString(resultValue: Any?): CharSequence {
                return (resultValue as CountryNamesItem).country_name
            }
            override fun performFiltering(constraint: CharSequence?): FilterResults {
                val filterResults = FilterResults()
                if (constraint != null) {
                    val citySuggestion: MutableList<CountryNamesItem> = ArrayList()
                    for (city in allCities) {
                        if (city.country_name.toLowerCase() .startsWith(constraint.toString().toLowerCase())
                        ) {
                            citySuggestion.add(city)
                        }
                    }
                    filterResults.values = citySuggestion
                    filterResults.count = citySuggestion.size
                }
                return filterResults
            }

            override fun publishResults(constraint: CharSequence?, results: FilterResults) {
                city.clear()
                if (results.count > 0) {
                    for (result in results.values as List<*>) {
                        if (result is CountryNamesItem) {
                            city.add(result)
                        }
                    }
                    notifyDataSetChanged()
                } else if (constraint == null) {
                    city.addAll(allCities)
                    notifyDataSetInvalidated()
                }
            }


        }
    }
}