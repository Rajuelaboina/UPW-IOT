package com.phycae.iot.viewmodel

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.phycae.iot.adapter.ChannelAdapter
import com.phycae.iot.model.Channel
import com.phycae.iot.model.Channel_Temp
import com.phycae.iot.model.Feed
import com.phycae.iot.model.Feed_Temp
import com.phycae.iot.repo.ChannelRepo


class ChannelViewModel(private var channelRepo: ChannelRepo) :ViewModel() {
    val channelAdapter: ChannelAdapter
    var feedList = MutableLiveData<List<Feed>>()
    var channelList = MutableLiveData<Channel>()

    var tempfeedList = MutableLiveData<List<Feed_Temp>>()
    var tempchannelList = MutableLiveData<Channel_Temp>()
    init {
        channelRepo = ChannelRepo()
        channelAdapter = ChannelAdapter()
    }
    fun getAllFeeds():LiveData<List<Feed>>{
        return channelRepo.feedList

    }
    fun getChannel(): LiveData<Channel> {
        channelList = channelRepo.getChannel()
        return channelList
    }

    fun getTempChannel(): LiveData<Channel_Temp> {
        tempchannelList = channelRepo.getTempChannel()
        return tempchannelList
    }

    fun getTempFeeds(): LiveData<List<Feed_Temp>> {
        tempfeedList = channelRepo.getTempFeeds()
        return tempfeedList
    }

    fun setAdapter(it: List<Feed>) {
        channelAdapter.updateList(it)
    }
    fun disChannelAdapter(): ChannelAdapter{
        return channelAdapter
    }
}