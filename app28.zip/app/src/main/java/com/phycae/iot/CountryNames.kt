package com.phycae.iot

class CountryNames : ArrayList<CountryNamesItem>()