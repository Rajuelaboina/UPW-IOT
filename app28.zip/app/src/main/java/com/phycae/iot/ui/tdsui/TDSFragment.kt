package com.phycae.iot.ui.tdsui

import android.annotation.SuppressLint
import android.content.Context
import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.databinding.DataBindingUtil
import androidx.fragment.app.Fragment
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModelProvider
import androidx.recyclerview.widget.DividerItemDecoration
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView.ItemDecoration
import com.google.android.material.snackbar.Snackbar
import com.phycae.iot.R
import com.phycae.iot.adapter.ChannelAdapter
import com.phycae.iot.databinding.FragmentTdsBinding
import com.phycae.iot.listeners.ItemSelecetedListener
import com.phycae.iot.repo.ChannelRepo
import com.phycae.iot.utils.CheckNetworkConnection
import com.phycae.iot.utils.ProgressUtill
import com.phycae.iot.viewmodel.ChannelViewModel
import com.phycae.iot.viewmodelhelper.ChannelViewModelHelper


class TDSFragment: Fragment() , ItemSelecetedListener {
    lateinit var binding : FragmentTdsBinding
    lateinit var viewModel: ChannelViewModel
    lateinit var channelRepo: ChannelRepo


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
    }

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?,savedInstanceState: Bundle?): View? {
        binding = DataBindingUtil.inflate(inflater, R.layout.fragment_tds,container,false)
        return binding.root
    }

    @SuppressLint("SuspiciousIndentation", "FragmentLiveDataObserve")
    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        channelRepo = ChannelRepo()
        viewModel = ViewModelProvider(this, ChannelViewModelHelper(channelRepo))[ChannelViewModel::class.java]
        binding.executePendingBindings()
        binding.channelViewModel = viewModel
       // ProgressUtill.showProgress(this,binding.recyclerView)
        binding.tabLayout.visibility = View.INVISIBLE
        if (CheckNetworkConnection.isInternetOn(requireContext())){
            viewModel.getAllFeeds().observe(this, Observer {

                binding.progressBar.visibility=View.INVISIBLE
                if (it!=null)
                    binding.tabLayout.visibility = View.VISIBLE
                viewModel.setAdapter(it)
            })
            binding.recyclerView.addItemDecoration(DividerItemDecoration(context,LinearLayoutManager.VERTICAL))
            ChannelAdapter.onItemSelectedListener(this)
        }else{
            Snackbar.make(binding.constraintLayoutTds,"check Internet connection", Snackbar.LENGTH_LONG).show()
            binding.progressBar.visibility=View.INVISIBLE
        }

    }


    override fun onItemClick(position: Int) {
       Log.e("itemClik ","selectedItem: $position")
    }


}