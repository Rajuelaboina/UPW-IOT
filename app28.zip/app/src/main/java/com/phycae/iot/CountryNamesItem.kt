package com.phycae.iot

data class CountryNamesItem(
    val country_name: String,
    val country_phone_code: Int,
    val country_short_name: String
)