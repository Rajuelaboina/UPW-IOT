package com.phycae.iot

import android.annotation.SuppressLint
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.widget.AutoCompleteTextView
import android.widget.Spinner
import com.phycae.iot.apis.RetrofitRequest
import io.reactivex.Observer
import io.reactivex.android.schedulers.AndroidSchedulers
import io.reactivex.disposables.Disposable
import io.reactivex.schedulers.Schedulers

class CountryActivity : AppCompatActivity() {
    lateinit var spinner:Spinner
    lateinit var auto : AutoCompleteTextView
    @SuppressLint("MissingInflatedId")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_country)
        spinner = findViewById(R.id.spinner)
        auto = findViewById(R.id.autoCompleteTextView)
        val apiKey = "9yCXjLVinslQ37Lly1lqynEFOgs8xBrh_Mk3czO5gBhbr_LinlaS3nbkPu5RCIPVNvw"
        val email = "rakeshios123@gmail.com"
        RetrofitRequest.getRetrofitInstance().getAuthToken(apiKey,email).subscribeOn(Schedulers.io())
            .observeOn(AndroidSchedulers.mainThread())
            .subscribe(object :Observer<AuthoToken>{
                override fun onSubscribe(d: Disposable) {

                }

                override fun onError(e: Throwable) {

                }

                override fun onComplete() {

                }

                override fun onNext(t: AuthoToken) {
                    Log.e("AuthoToken","AuthoToken: ${t.auth_token}")
                    getCountrys(t.auth_token)
                }
        })

    }
    fun getCountrys(authToken: String) {
        val authToken2 = "Bearer "+authToken
        RetrofitRequest.getRetrofitInstance().getCountryNames(authToken2)
            .subscribeOn(Schedulers.io())
            .observeOn(AndroidSchedulers.mainThread())
             .subscribe(object :Observer<List<CountryNamesItem>>{
                 override fun onNext(t: List<CountryNamesItem>) {
                     Log.e("CountryNames","CountryNames: ${t.size}")
                     for (x in 0 until t.size)
                         Log.e("CountryNames","CountryNames: ${t[x].country_name}")
                     val adapter = CountryAdapter(t)
                     spinner.adapter =adapter
                     val adapter2 = CountryAdapter2(applicationContext,R.layout.row_item,t)
                     auto.setAdapter(adapter2)
                 }

                 override fun onSubscribe(d: Disposable) {

                 }

                 override fun onError(e: Throwable) {

                 }

                 override fun onComplete() {

                 }

             })
            /*.subscribe(object :Observer<CountryNames>{
                override fun onSubscribe(d: Disposable) {

                }

                override fun onError(e: Throwable) {

                }

                override fun onComplete() {

                }

                override fun onNext(t: CountryNames) {
                    Log.e("CountryNames","CountryNames: ${t.size}")
                    for (x in 0 until t.size)
                        Log.e("CountryNames","CountryNames: ${t[x].country_name}")
                    val adapter = CountryAdapter(t)
                    spinner.adapter =adapter
                    val adapter2 = CountryAdapter2(applicationContext,R.layout.row_item,t)
                    auto.setAdapter(adapter2)
                }

            })*/
    }
}