package com.phycae.iot

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.BaseAdapter
import android.widget.TextView

class CountryAdapter(var list: List<CountryNamesItem>) : BaseAdapter() {

    override fun getCount(): Int {
       return list.size
    }

    override fun getItem(position: Int): Any {
       return list[position]
    }

    override fun getItemId(position: Int): Long {
      return 0
    }

    override fun getView(position: Int, convertView: View?, parent: ViewGroup?): View {
       val view = LayoutInflater.from(parent!!.context).inflate(R.layout.row_item,null)
        val tv1 = view.findViewById<TextView>(R.id.textView_created_at)
        tv1.text = list[position].country_phone_code.toString()
        val tv2 = view.findViewById<TextView>(R.id.textView_feed)
        tv2.text = list[position].country_name
        return view
    }
}