package com.phycae.iot.viewmodelhelper

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import com.phycae.iot.repo.ChannelRepo
import com.phycae.iot.viewmodel.ChannelViewModel

class ChannelViewModelHelper(var repo: ChannelRepo): ViewModelProvider.Factory {
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        return if (modelClass.isAssignableFrom(ChannelViewModel::class.java)){
            ChannelViewModel(this.repo) as T
        }else{
            throw IllegalArgumentException("ViewModel Not Found")
        }
    }
}