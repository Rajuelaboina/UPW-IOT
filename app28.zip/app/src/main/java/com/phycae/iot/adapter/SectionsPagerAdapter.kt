package com.phycae.iot.adapter

import android.content.Context
import androidx.fragment.app.Fragment
import androidx.fragment.app.FragmentManager
import androidx.fragment.app.FragmentPagerAdapter
import com.phycae.iot.ui.tdsui.TDSFragment
import com.phycae.iot.ui.phui.PHFragment
import com.phycae.iot.ui.tempui.TempFragment

class SectionsPagerAdapter(context: Context,fm: FragmentManager) : FragmentPagerAdapter(fm) {

    override fun getCount(): Int {
        return 3
    }

    override fun getItem(position: Int): Fragment {
        when(position) {
            0 -> {
                return TDSFragment()
            }
            1 -> {
                return PHFragment()
            }
            2 ->{
                return TempFragment()
            }

            else -> {
                return TDSFragment()
            }
        }
    }

    override fun getPageTitle(position: Int): CharSequence? {
        when(position) {
            0 -> {
                return "TDS"
            }
            1 -> {
                return "PH"
            }
            2 -> {
                return "TEMP"
            }

        }
        return super.getPageTitle(position)
    }
}