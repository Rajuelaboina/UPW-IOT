package com.phycae.iot

data class AuthoToken(
    val auth_token: String
)