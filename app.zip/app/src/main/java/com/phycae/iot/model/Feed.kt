package com.phycae.iot.model

data class Feed(
    val created_at: String,
    val entry_id: Int,
    val field1: String
)