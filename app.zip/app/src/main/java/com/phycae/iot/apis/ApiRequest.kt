package com.phycae.iot.apis

import com.phycae.iot.model.TDSValues
import com.phycae.iot.model.TempHumidity
import io.reactivex.Observable
import retrofit2.Call
import retrofit2.http.GET

interface ApiRequest {
   // @GET("/channels/1984207/feeds.json?api_key=DAZGXH8X5X7HJUTX&results")
    @GET("/channels/1984207/feeds.json?api_key=DAZGXH8X5X7HJUTX&results")
    fun getTdsvalue(): Observable<TDSValues>
   // fun getTdsvalue(): Call<TDSValues>

    // get the temp and humidity values
    @GET("/channels/2195608/feeds.json?api_key=LY1ET7MNJXDVTI96&results=2")
    fun getTempAndHumidity(): Call<TempHumidity>
}