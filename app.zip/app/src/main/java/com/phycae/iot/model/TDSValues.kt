package com.phycae.iot.model

data class TDSValues(
    val channel: Channel,
    val feeds: List<Feed>
)