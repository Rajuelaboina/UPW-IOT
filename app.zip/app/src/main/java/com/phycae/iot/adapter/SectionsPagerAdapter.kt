package com.phycae.iot.adapter

import android.content.Context
import androidx.fragment.app.Fragment
import androidx.fragment.app.FragmentManager
import androidx.fragment.app.FragmentPagerAdapter
import com.phycae.iot.ui.tdsui.TDSFragment
import com.phycae.iot.ui.phui.PHFragment

class SectionsPagerAdapter(context: Context,fm: FragmentManager) : FragmentPagerAdapter(fm) {

    override fun getCount(): Int {
        return 2
    }

    override fun getItem(position: Int): Fragment {
        when(position) {
            0 -> {
                return TDSFragment()
            }
            1 -> {
                return PHFragment()
            }

            else -> {
                return TDSFragment()
            }
        }
    }

    override fun getPageTitle(position: Int): CharSequence? {
        when(position) {
            0 -> {
                return "TDS"
            }
            1 -> {
                return "PH"
            }

        }
        return super.getPageTitle(position)
    }
}