package com.phycae.iot.listeners;

public interface ItemSelecetedListener {
    void onItemClick(int position);
}
