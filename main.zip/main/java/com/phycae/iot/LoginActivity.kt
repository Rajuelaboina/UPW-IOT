package com.phycae.iot

import android.content.Intent
import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.databinding.DataBindingUtil
import com.phycae.iot.databinding.ActivityLoginBinding
import com.phycae.iot.model.User


class LoginActivity : AppCompatActivity() {
    lateinit var binding: ActivityLoginBinding
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding= DataBindingUtil.setContentView(this,R.layout.activity_login)
        val loginCheck: Boolean = SharedPrefManager.getInstance(applicationContext).isUserLoggedIn()

        if (loginCheck) {
            startActivity(Intent(this@LoginActivity, HomeActivity::class.java))
            finish()
        }
        binding.LoginButton.setOnClickListener {
            val name: String = binding.editTextTextPersonName.getText().toString()
            val password: String = binding.editTextTextPassword.getText().toString()
            if (isValidations(name, password)) {
                if (name == "MSL" && password == "msl@2023") {
                    //saveDataFromSharedPref(name,password);
                    SharedPrefManager.getInstance(applicationContext)
                        .insetUserData(User("MSL", "msl@2023"))
                    startActivity(Intent(this@LoginActivity, HomeActivity::class.java))
                    finish()
                } else if (name == "user1" && password == "user1@2023") {
                    SharedPrefManager.getInstance(applicationContext)
                        .insetUserData(User("user1", "user1@2023"))
                    startActivity(Intent(this@LoginActivity, HomeActivity::class.java))
                    finish()
                } else if (name == "user2" && password == "user2@2023") {
                    SharedPrefManager.getInstance(applicationContext)
                        .insetUserData(User("user2", "user2@2023"))
                    startActivity(Intent(this@LoginActivity, HomeActivity::class.java))
                    finish()
                } else {
                    Toast.makeText(
                        applicationContext,
                        "username or password is incorrect",
                        Toast.LENGTH_SHORT
                    ).show()
                }
            } else {
                Toast.makeText(applicationContext, "fields are not empty", Toast.LENGTH_SHORT)
                    .show()
            }
        }

    }
    private fun isValidations(name: String, password: String): Boolean {
        val boo = true
        return if (name.isEmpty() && password.isEmpty()) {
            false
        } else boo
    }
}