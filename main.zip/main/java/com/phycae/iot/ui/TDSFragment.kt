package com.phycae.iot.ui

import android.annotation.SuppressLint
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.databinding.DataBindingUtil
import androidx.fragment.app.Fragment
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModelProvider
import com.phycae.iot.R
import com.phycae.iot.databinding.FragmentTdsBinding
import com.phycae.iot.listeners.ItemSelecetedListener
import com.phycae.iot.repo.ChannelRepo
import com.phycae.iot.utils.ProgressUtill
import com.phycae.iot.viewmodel.ChannelViewModel
import com.phycae.iot.viewmodelhelper.ChannelViewModelHelper


class TDSFragment: Fragment() , ItemSelecetedListener {
    lateinit var binding : FragmentTdsBinding
    lateinit var viewModel: ChannelViewModel
    lateinit var channelRepo: ChannelRepo
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
    }

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?,savedInstanceState: Bundle?): View? {
        binding = DataBindingUtil.inflate(inflater, R.layout.fragment_tds,container,false)
        return binding.root
    }

    @SuppressLint("SuspiciousIndentation", "FragmentLiveDataObserve")
    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        channelRepo = ChannelRepo()
        viewModel = ViewModelProvider(this, ChannelViewModelHelper(channelRepo))[ChannelViewModel::class.java]
        binding.executePendingBindings()
        binding.channelViewModel = viewModel
       // ProgressUtill.showProgress(this,binding.recyclerView)

        viewModel.getAllFeeds().observe(this, Observer {

           binding.progressBar.visibility=View.INVISIBLE
            if (it!=null)

            viewModel.setAdapter(it)
        })

    }


    override fun onItemClick(position: Int) {

    }


}