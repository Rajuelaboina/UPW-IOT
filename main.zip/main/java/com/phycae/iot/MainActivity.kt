package com.phycae.iot

import android.os.Bundle
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.databinding.DataBindingUtil
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModelProvider
import com.phycae.iot.databinding.ActivityMainBinding
import com.phycae.iot.repo.ChannelRepo
import com.phycae.iot.ui.SectionsPagerAdapter
import com.phycae.iot.utils.DateUtils
import com.phycae.iot.viewmodel.ChannelViewModel
import com.phycae.iot.viewmodelhelper.ChannelViewModelHelper


class MainActivity : AppCompatActivity() {
    lateinit var date_title: TextView
    lateinit var binding: ActivityMainBinding
    lateinit var sectionsPagerAdapter: SectionsPagerAdapter
    lateinit var viewModel: ChannelViewModel
    lateinit var channelRepo: ChannelRepo
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding=DataBindingUtil.setContentView(this,R.layout.activity_main)
        date_title=binding.dateTitle
        sectionsPagerAdapter = SectionsPagerAdapter(applicationContext,supportFragmentManager)
        val viewPager = binding.viewPager
        viewPager.adapter =sectionsPagerAdapter
        val tableLayout = binding.tabs
        tableLayout.setupWithViewPager(viewPager)
        val id = intent.getStringExtra("ID")
        if (id.equals("1")){
            tableLayout.getTabAt(0)?.select();
        }else if (id.equals("2")){
            tableLayout.getTabAt(1)?.select();
        }
        channelRepo = ChannelRepo()
        viewModel = ViewModelProvider(this, ChannelViewModelHelper(channelRepo))[ChannelViewModel::class.java]
        binding.executePendingBindings()
        viewModel.getChannel().observe(this, Observer {
            val str: String = it.created_at
            binding.dateTitle.setText(DateUtils.getDate(str))
        })
    }

}