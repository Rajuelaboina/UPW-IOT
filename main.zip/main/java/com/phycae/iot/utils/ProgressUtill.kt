package com.phycae.iot.utils

import android.content.Context
import android.view.View
import android.view.ViewGroup
import android.widget.ProgressBar

class ProgressUtill {

    companion object{
       lateinit var  prog: ProgressBar

       fun showProgress(context: Context, linear1: ViewGroup){
           prog =  ProgressBar(context);
           prog.setVisibility(View.VISIBLE);
           linear1.addView(prog);
       }
        fun hideProgress(context: Context){
            prog.setVisibility(View.GONE)
        }
    }
}