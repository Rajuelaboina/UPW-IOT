package com.phycae.iot


import android.content.DialogInterface
import android.content.Intent
import android.os.Bundle
import android.view.Menu
import android.view.MenuItem
import androidx.appcompat.app.AppCompatActivity
import androidx.databinding.DataBindingUtil
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModelProvider
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import com.phycae.iot.databinding.ActivityHomeBinding
import com.phycae.iot.listeners.ItemSelecetedListener
import com.phycae.iot.model.User
import com.phycae.iot.repo.ChannelRepo
import com.phycae.iot.utils.DateUtils
import com.phycae.iot.utils.ProgressUtill
import com.phycae.iot.viewmodel.ChannelViewModel
import com.phycae.iot.viewmodelhelper.ChannelViewModelHelper


class HomeActivity : AppCompatActivity(), ItemSelecetedListener {
    lateinit var binding: ActivityHomeBinding
    lateinit var user: User
    lateinit var viewModel: ChannelViewModel
    lateinit var channelRepo: ChannelRepo
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding= DataBindingUtil.setContentView(this,R.layout.activity_home)
        user =SharedPrefManager.getInstance(getApplicationContext()).getUserData();
        binding.textViewUsername.setText("Name: "+user.name)
        ProgressUtill.showProgress(getApplicationContext(),binding.linearLayout5)
        channelRepo = ChannelRepo()
        viewModel = ViewModelProvider(this,ChannelViewModelHelper(channelRepo))[ChannelViewModel::class.java]
        loadData()
        binding.TDStextView.setOnClickListener {
                val intent = Intent(this@HomeActivity, MainActivity::class.java)
                intent.putExtra("ID", "1")
                startActivity(intent)
        }

        binding.PHtextView.setOnClickListener {
            val intent = Intent(this@HomeActivity, MainActivity::class.java)
            intent.putExtra("ID", "2")
            startActivity(intent)
        }




    }

    private fun loadData() {
        viewModel.getAllFeeds().observe(this, Observer {
            ProgressUtill.hideProgress(getApplicationContext())
            if (it!=null) {
                val tds: String = it.get(it.size - 2).field1.trim()
                binding.textViewTdsValue.text = tds.substring(0, 4).trim { it <= ' ' }
                binding.textViewLastSynDate.text =
                    "Last Sync: " + DateUtils.getDateTime(it.get(it.size - 2).created_at)
            }
        })
        viewModel.getChannel().observe(this, Observer {
            ProgressUtill.hideProgress(getApplicationContext())
            binding.textViewRole.setText("Chanel Id: "+it.id.toString())
            binding.textViewMobile.setText("Channel Name: "+it.name)
        })
        // values from temp and Humidity
        viewModel.getTempFeeds().observe(this, Observer {
            ProgressUtill.hideProgress(getApplicationContext())
            binding.textViewTempValue.setText(it.get(it.size-1).field1.trim().substring(0,4));
            binding.textViewHmValue.setText(it.get(it.size-1).field2.trim().substring(0,4));
        })
        /*viewModel.getTempChannel().observe(this, Observer {

        })*/

    }

    override fun onCreateOptionsMenu(menu: Menu): Boolean {
       menuInflater.inflate(R.menu.user_menu,menu)
        return true
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        if (item.getItemId() == R.id.logout) {
             MaterialAlertDialogBuilder(this@HomeActivity,R.style.RoundShapeTheme)
                 .setMessage("Do you want close this app")
                 .setPositiveButton("Yes", DialogInterface.OnClickListener { dialog, which ->
                     SharedPrefManager.getInstance(getApplicationContext()).isLogedout()
                 })
                 .setNegativeButton("Cancel", DialogInterface.OnClickListener { dialog, which ->
                     dialog.dismiss()
                 })
                 .show()


        }
        return true
    }

    override fun onItemClick(position: Int) {
        startActivity(Intent(this@HomeActivity, MainActivity::class.java))
    }
}