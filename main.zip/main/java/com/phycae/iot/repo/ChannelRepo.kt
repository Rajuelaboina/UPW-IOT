package com.phycae.iot.repo

import android.util.Log
import androidx.lifecycle.MutableLiveData
import com.phycae.iot.apis.RetrofitRequest
import com.phycae.iot.model.*
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response


class ChannelRepo {
    var feedList =  MutableLiveData<List<Feed>>()
    var channelList =  MutableLiveData<Channel>()

    var tempFeedList = MutableLiveData<List<Feed_Temp>>()
    var tempChannelList = MutableLiveData<Channel_Temp>()

    init {
        getAllData()
        getTempHumidity()
    }



    private fun getAllData() {
        val call: Call<TDSValues> = RetrofitRequest.getRetrofitInstance().getTdsvalue()
        call.enqueue(object :Callback<TDSValues>{
            override fun onResponse(call: Call<TDSValues>, response: Response<TDSValues>) {
                if (response.isSuccessful) {
                    channelList.postValue(response.body()?.channel)
                    feedList.postValue(response.body()?.feeds)
                }
            }

            override fun onFailure(call: Call<TDSValues>, t: Throwable) {
                channelList.postValue(null)
                feedList.postValue(null)
            }

        })
    }

    fun getAllFeeds(): MutableLiveData<List<Feed>> {
        return feedList
    }

    fun getChannel(): MutableLiveData<Channel> {
        return channelList
    }
   // get the temp and humidity values
    private fun getTempHumidity() {
       val call = RetrofitRequest.getRetrofitInstance().getTempAndHumidity()
       call.enqueue(object :Callback<TempHumidity>{
           override fun onResponse(call: Call<TempHumidity>, response: Response<TempHumidity>) {
               if (response.isSuccessful)
               tempFeedList.postValue(response.body()?.feeds)
               tempChannelList.postValue(response.body()?.channel)

           }

           override fun onFailure(call: Call<TempHumidity>, t: Throwable) {
               tempFeedList.postValue(null)
               tempChannelList.postValue(null)
           }

       })
    }

    fun getTempChannel(): MutableLiveData<Channel_Temp> {
        return tempChannelList
    }

    fun getTempFeeds(): MutableLiveData<List<Feed_Temp>> {
        return tempFeedList
    }
}