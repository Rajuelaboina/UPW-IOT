package com.phycae.iot

import android.content.Context
import android.content.Context.MODE_PRIVATE
import android.content.Intent
import com.phycae.iot.model.User


class SharedPrefManager {

    companion object{
        lateinit var context:Context
        fun getInstance(context: Context):SharedPrefManager{
            this.context =context
            var sharedPrefManager : SharedPrefManager? =null
            if (sharedPrefManager==null){
                sharedPrefManager = SharedPrefManager()
            }
            return sharedPrefManager
        }
    }

    fun insetUserData(user: User) {
        val sharedPreferences = context.getSharedPreferences("MyIOTSharedPref", MODE_PRIVATE)
        val myEdit = sharedPreferences.edit()
        myEdit.putString("name", user.name)
        myEdit.putString("password", user.password)
        myEdit.putBoolean("OK", true)
        myEdit.commit()
    }
    fun getUserData(): User {
        val sharedPreferences = context.getSharedPreferences("MyIOTSharedPref", MODE_PRIVATE)
        return User(
            sharedPreferences.getString("name", null),
            sharedPreferences.getString("password", null)
        )
    }
    fun isLogedout() {
        val sharedPreferences = context.getSharedPreferences("MyIOTSharedPref", MODE_PRIVATE)
        val editor = sharedPreferences.edit()
        editor.clear()
        editor.apply()
        val intent = Intent(context, LoginActivity::class.java)
        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_CLEAR_TASK)
        context.startActivity(intent)
    }
    fun isUserLoggedIn(): Boolean {
        val sharedPreferences = context.getSharedPreferences("MyIOTSharedPref", MODE_PRIVATE)
        return if (sharedPreferences.getString("name", null) != null) {
            true
        } else false
    }
}